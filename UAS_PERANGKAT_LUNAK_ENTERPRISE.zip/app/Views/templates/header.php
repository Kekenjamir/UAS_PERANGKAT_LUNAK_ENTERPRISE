<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>


<!-- navbar -->
<style>
    .navbar-nav .nav-link {
        margin-right: 15px;
        color: #058F3F;
    }
</style>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container">
        <a class="navbar-brand" href="home">
            <img src="images/logo.png" alt="Logo" width="200" height="50">
        </a>
        <div class="navbar-nav ml-auto">
            <a class="nav-link" href="tourism">Tourism</a>
            <a class="nav-link" href="cafe">Cafe</a>
            <a class="nav-link" href="event">Event</a>
            <a class="nav-link" href="about">About Us</a>
        </div>
    </div>
</nav>