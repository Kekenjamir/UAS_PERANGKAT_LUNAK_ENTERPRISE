<!-- footer -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:ital,wght@1,300&display=swap" rel="stylesheet">
<style>
    .bg-body-tertiary {
        text-align: center;
        /* Mengatur teks menjadi rata tengah */

        font-family: 'Roboto Mono', monospace;
    }

    p {
        margin: 1px 0;
        /* Mengatur margin atas dan bawah menjadi 1px */
    }
</style>

<footer class="bg-body-tertiary">
    <p>UJIAN AKHIR SEMESTER</p>
    <P>MATA KULIAH PERANGKAT LUNAK ENTERPRISE</P>
    <em>&copy; 2023</em>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</body>

</html>