<style>
    .container p {
        text-align: justify;
    }

    body {
        background-color: #E8F8F5;
    }
</style>

<!-- section 1 -->
<div class="container my-4">
    <h1>Coffe Toffe</h1>
    <img src="images/coffeetoffee.jpg" class="img-fluid" alt="Coffeetofee">
</div>


<!-- section 2 -->
<div class="container my-4">
    <h3>Jam Operasional</h3>
    <p>-</p>
</div>


<!-- section 3 -->
<div class="container my-4">
    <h3>Instagram</h3>
    <p>Rp 5000/Orang</p>
</div>

<!-- section 4 -->
<div class="container my-4">
    <h3>Alamat</h3>
    <p>Jl. Diponegoro</p>
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d26823.38140758186!2d113.77958672015212!3d-2.0279211124621734!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dfcbf4f21d82bef%3A0x794ba800a99877e5!2sDanau%20Tahai!5e0!3m2!1sen!2sid!4v1687282168424!5m2!1sen!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>